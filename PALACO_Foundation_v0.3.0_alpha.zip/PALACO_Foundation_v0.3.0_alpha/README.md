# PALACO_Foundation_v0.3.0_alpha

Adds initial Plugin API and Event Bus placeholders.
